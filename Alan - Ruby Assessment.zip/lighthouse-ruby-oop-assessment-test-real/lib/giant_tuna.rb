class GiantTuna < Fish
  def initialize
    super(2, 25)
  end
end